# mypackage
This library was created as an example on how to publish my first package
# myModule
What the package actally does is to take an array of numbers and return the top n 
numbers in descending order.

# fibModule
This module in the package calculates the fibonacci numbers provided a positive integer given.