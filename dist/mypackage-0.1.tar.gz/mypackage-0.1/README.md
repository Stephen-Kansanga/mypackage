# mypackage
This library was created as an example on how to publish my first package
What the package actally does is to take an array of numbers and return the top n 
numbers in descending order.

# How to install
...